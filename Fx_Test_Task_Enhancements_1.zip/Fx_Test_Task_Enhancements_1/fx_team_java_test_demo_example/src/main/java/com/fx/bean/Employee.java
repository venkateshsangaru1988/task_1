package com.fx.bean;



public class Employee {

	private Long company_code;
	private Long account;
	private String city;
	private String country;
	private String credit_rating;
	private String currency;
	private Double amount;
	public Employee() {
		super();
	}
	public Employee(Long company_code, Long account, String city, String country, String credit_rating, String currency,
			Double amount) {
		super();
		this.company_code = company_code;
		this.account = account;
		this.city = city;
		this.country = country;
		this.credit_rating = credit_rating;
		this.currency = currency;
		this.amount = amount;
	}
	public Long getCompany_code() {
		return company_code;
	}
	public void setCompany_code(Long company_code) {
		this.company_code = company_code;
	}
	public Long getAccount() {
		return account;
	}
	public void setAccount(Long account) {
		this.account = account;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCredit_rating() {
		return credit_rating;
	}
	public void setCredit_rating(String credit_rating) {
		this.credit_rating = credit_rating;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "[countryCriteria=" + country + ", creditRatingCriteria=" + credit_rating + ", Value=" + amount + "]";
	}
	
	

	

}
