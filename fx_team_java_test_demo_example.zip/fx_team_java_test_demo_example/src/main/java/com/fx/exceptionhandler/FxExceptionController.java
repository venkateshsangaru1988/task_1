package com.fx.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class FxExceptionController {
	
	@ExceptionHandler(value = FxFileNotfoundException.class)
	   public ResponseEntity<Object> exception(FxFileNotfoundException exception) {
	      return new ResponseEntity<>("FX File not found", HttpStatus.NOT_FOUND);
	   }


}
