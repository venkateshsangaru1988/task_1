package com.fx.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fx.bean.Employee;
import com.fx.exceptionhandler.FxFileNotfoundException;

@Component
public class FxService {

	private static List<Employee> empList = new ArrayList<>();
	public Double readFileAndCalculateAvg() {

		Double average=null;
		File file = new File(new FxService().getClass().getClassLoader().getResource("FILE.DAT").getFile());
		if(file == null) {
			throw new FxFileNotfoundException();
		}

		BufferedReader buf = null;
		try {
			buf = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e1) {
		}
		String lineJustFetched = null;
		while (true) {
			try {
				lineJustFetched = buf.readLine();
			} catch (IOException e) {
			}
			if (lineJustFetched == null) {
				break;
			} else {

				addDataToEmployee(lineJustFetched);
			}
		}

		try {
			buf.close();
		} catch (IOException e) {
		}

		average = findAverageEmplist(empList);
		return average;


	}
	static void addDataToEmployee(String lineJustFetched) {

		String[] wordsArray;
		int i = 1;
		if (lineJustFetched != null && !lineJustFetched.contains("Company_Code")) {

			Employee e = new Employee();
			wordsArray = lineJustFetched.split("\t");
			if (wordsArray.length == 7) {

				for (String each : wordsArray) {

					if (i == 1 && each != " ")
						e.setCompany_code(Long.parseLong(each));
					if (i == 2 && each != " ")
						e.setAccount(Long.parseLong(each));
					if (i == 3)
						e.setCity(each);
					if (i == 4)
						e.setCountry(each);
					if (i == 5)
						e.setCredit_rating(each);
					if (i == 6)
						e.setCurrency(each);
					if (i == 7)
						e.setAmount(Double.parseDouble(each));

					i++;
				}
			}

			empList.add(e);
		}

	}

	static Double findAverageEmplist(List<Employee> employeeList){

		return employeeList.stream().mapToDouble(Employee::getAmount)
				.average()
				.getAsDouble();
	}


}
