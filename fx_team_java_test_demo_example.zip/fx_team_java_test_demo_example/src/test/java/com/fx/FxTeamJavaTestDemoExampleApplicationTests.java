package com.fx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FxTeamJavaTestDemoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
