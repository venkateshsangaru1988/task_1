package com.fx.team;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class WordsInArray {

	public static List<Employee> empList = new ArrayList<Employee>();

	public static void main(String[] args) {

		try {

			File file = new File(new WordsInArray().getClass().getClassLoader().getResource("FILE.DAT").getFile());
			BufferedReader buf = new BufferedReader(new FileReader(file));
			String lineJustFetched = null;
			while (true) {
				lineJustFetched = buf.readLine();
				if (lineJustFetched == null) {
					break;
				} else {

					addDataToEmployee(lineJustFetched);
				}
			}

			System.out.println(empList.size());
			for(Employee l : empList) {
				
				System.out.println(l);
			}
			buf.close();

			
			Double average = findAverageEmplist(empList);
			System.out.println("Final Average -- " + average);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	static void addDataToEmployee(String lineJustFetched) {

		String[] wordsArray;
		int i = 1;
		if (lineJustFetched != null && !lineJustFetched.contains("Company_Code")) {

			Employee e = new Employee();
			wordsArray = lineJustFetched.split("\t");
			if (wordsArray.length == 7) {

				for (String each : wordsArray) {

					if (i == 1 && each != " ")
						e.setCompany_code(Long.parseLong(each));
					if (i == 2 && each != " ")
						e.setAccount(Long.parseLong(each));
					if (i == 3)
						e.setCity(each);
					if (i == 4)
						e.setCountry(each);
					if (i == 5)
						e.setCredit_rating(each);
					if (i == 6)
						e.setCurrency(each);
					if (i == 7)
						e.setAmount(Double.parseDouble(each));

					i++;
				}
			}

			empList.add(e);
		}
		
	}
	
	static Double findAverageEmplist(List<Employee> employeeList){
		
		return employeeList.stream().mapToDouble(Employee::getAmount)
        .average()
        .getAsDouble();
	}
}