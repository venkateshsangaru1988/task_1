package com.fx;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;

import org.junit.jupiter.api.Test;

import com.fx.service.FxService;

public class FileReadTest extends FxTeamJavaTestDemoExampleApplicationTests{
	
	@Test
	public void readFileTest() {

		int fileCountFlag=0;
		int actualValue=1;
		
		File file = new File(new FxService().getClass().getClassLoader().getResource("FILE.DAT").getFile());
		
		if(file!=null) {
			fileCountFlag=1;
		}
		
		assertEquals(actualValue, fileCountFlag);
		
	}

}
