package com.fx.exceptionhandler;

public class FxFileNotfoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}


