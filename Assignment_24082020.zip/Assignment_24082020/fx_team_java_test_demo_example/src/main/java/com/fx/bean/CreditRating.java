package com.fx.bean;

public class CreditRating {

	private String countryCriteria;
	private String creditRatingCriteria;
	private Double value;

	public String getCountryCriteria() {
		return countryCriteria;
	}
	public void setCountryCriteria(String countryCriteria) {
		this.countryCriteria = countryCriteria;
	}
	public String getCreditRatingCriteria() {
		return creditRatingCriteria;
	}
	public void setCreditRatingCriteria(String creditRatingCriteria) {
		this.creditRatingCriteria = creditRatingCriteria;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}


}
