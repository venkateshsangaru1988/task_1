package com.fx;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.fx.service.FxService;

public class AvgSalaryTest extends FxTeamJavaTestDemoExampleApplicationTests{

	@Autowired private  FxService fxService;
	@Test
	public void avgSalaryTest() {
		Double actualValue=2.874917115777103E8;
		Double average=fxService.readFileAndCalculateAvg();	
		assertEquals(actualValue, average);

	}





}
