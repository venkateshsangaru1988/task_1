package com.fx;

import java.io.File;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.fx.service.FxService;

@SpringBootTest
class FxTeamJavaTestDemoExampleApplicationTests {

	@Test
	public void contextLoads() {
	}

	

}
