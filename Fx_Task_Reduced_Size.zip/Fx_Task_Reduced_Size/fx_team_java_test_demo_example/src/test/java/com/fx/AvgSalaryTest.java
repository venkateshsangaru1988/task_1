package com.fx;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.fx.service.FxService;

public class AvgSalaryTest extends FxTeamJavaTestDemoExampleApplicationTests{

	@Autowired private  FxService fxService;
	@Test
	public void avgSalaryTest() {
		int actualValue=19;
		List<Map<String,Object>> creditRatingList=fxService.readFileAndCalculateAvg();	
		assertEquals(actualValue, creditRatingList.size());

	}





}
