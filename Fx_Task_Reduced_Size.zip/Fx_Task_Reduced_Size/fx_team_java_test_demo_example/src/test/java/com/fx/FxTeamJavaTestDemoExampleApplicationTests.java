package com.fx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FxTeamJavaTestDemoExampleApplicationTests {

	@Test
	public void contextLoads() {
	}

	

}
