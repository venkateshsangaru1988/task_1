package com.fx.validations;

public class EmployeeValidation {

	private String validation;


	public String getValidation() {
		return validation;
	}


	public void setValidation(String validation) {
		this.validation = validation;
	}


}
