package com.fx.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fx.service.FxService;

@RestController
public class FxController {

	@Autowired private  FxService fxService;
	
	@GetMapping
	public ResponseEntity<Object> readFileFromResource() { 
		
		List<Map<String,Object>> creditRatingList=fxService.readFileAndCalculateAvg();		
		
		return new ResponseEntity<>(creditRatingList, HttpStatus.OK);
	} 
}
